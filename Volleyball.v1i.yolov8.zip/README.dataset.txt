# Volleyball > 2025-11-30 7:37pm
https://universe.roboflow.com/omar-7mdnt/volleyball-n8htp

Provided by a Roboflow user
License: CC BY 4.0

